%% Calibração do Termopar via Curve Fitting
% Objetivo: encontrar a relação entre a temperatura lida pelo termopar (ESP32)
% e a temperatura real medida pelo multímetro, usando mínimos quadrados.
%
% Arquivos necessários na mesma pasta deste script:
%   termopar.txt   → colunas: [tempo_s, temp_termopar]
%   multimetro.txt → colunas: [tempo_s, temp_multimetro]

clc; clear; close all;

%% 1. Carregar dados
dados_termopar   = dlmread('termopar.txt', ',');
dados_multimetro = dlmread('multimetro.txt', ',');

t_termo  = dados_termopar(:, 1);   % tempo em segundos
T_termo  = dados_termopar(:, 2);   % temperatura do termopar (°C)

t_multi  = dados_multimetro(:, 1); % tempo em segundos
T_multi  = dados_multimetro(:, 2); % temperatura do multímetro (°C)

%% 2. Interpolar o termopar nos instantes do multímetro
% O termopar tem ~2024 amostras (1 por segundo)
% O multímetro tem 68 amostras (a cada 30 s)
% Interpolamos o termopar para ter os valores nos mesmos instantes do multímetro
T_termo_interp = interp1(t_termo, T_termo, t_multi, 'linear');

% Remover NaN caso haja instantes fora do range do termopar
mascara = ~isnan(T_termo_interp);
T_ref  = T_multi(mascara);         % temperatura "verdadeira" (multímetro)
T_med  = T_termo_interp(mascara);  % temperatura medida (termopar)

%% 3. Curve Fitting — modelo linear: T_real = a * T_termopar + b
% Este é o modelo mais simples e robusto para calibração de sensores
ft = fittype('a*x + b', 'independent', 'x', 'coefficients', {'a', 'b'});
opcoes = fitoptions('Method', 'NonlinearLeastSquares', ...
                    'StartPoint', [1, 0]);

[modelo, gof] = fit(T_med, T_ref, ft, opcoes);

a = modelo.a;
b = modelo.b;

fprintf('=== Resultado do Curve Fitting ===\n');
fprintf('Modelo: T_real = a * T_termopar + b\n');
fprintf('  a = %.6f\n', a);
fprintf('  b = %.6f °C\n', b);
fprintf('  R² = %.6f\n', gof.rsquare);
fprintf('  RMSE = %.4f °C\n', gof.rmse);

%% 4. Aplicar correção na série completa do termopar
T_termo_corrigido = a * T_termo + b;

%% 5. Visualização

figure('Name', 'Comparação Termopar x Multímetro', 'NumberTitle', 'off');

% 5.1 Série temporal
subplot(2,1,1);
plot(t_termo, T_termo, 'b-', 'LineWidth', 1, 'DisplayName', 'Termopar (bruto)');
hold on;
plot(t_termo, T_termo_corrigido, 'g-', 'LineWidth', 1.2, 'DisplayName', 'Termopar (corrigido)');
plot(t_multi, T_multi, 'ro', 'MarkerSize', 5, 'MarkerFaceColor', 'r', 'DisplayName', 'Multímetro');
xlabel('Tempo (s)');
ylabel('Temperatura (°C)');
title('Temperatura ao longo do tempo');
legend('Location', 'northwest');
grid on;

% 5.2 Correlação termopar x multímetro + curva ajustada
subplot(2,1,2);
scatter(T_med, T_ref, 20, 'b', 'filled', 'DisplayName', 'Dados interpolados');
hold on;
T_plot = linspace(min(T_med), max(T_med), 200);
plot(T_plot, a*T_plot + b, 'r-', 'LineWidth', 2, 'DisplayName', ...
    sprintf('Fit: %.4f·x + %.4f  (R²=%.4f)', a, b, gof.rsquare));
plot(T_plot, T_plot, 'k--', 'DisplayName', 'Ideal (y=x)');
xlabel('T_{termopar} interpolado (°C)');
ylabel('T_{multímetro} (°C)');
title('Correlação e ajuste por mínimos quadrados');
legend('Location', 'northwest');
grid on;

%% 6. Exportar série corrigida (opcional)
% Descomente se quiser salvar o resultado:
% resultado = [t_termo, T_termo, T_termo_corrigido];
% writematrix(resultado, 'termopar_corrigido.txt', 'Delimiter', ',');
% fprintf('Arquivo termopar_corrigido.txt salvo.\n');
